login = dict()

def registrarLog(user: str, pswd: str):
    login[user] = pswd

def mostrarLog():
    for i, (key, item) in enumerate(login.items()):
        print(f"Login {i+1} -> User: {key} -> Password: {item}")

def validarLog(user: str):
    while user.lower() in [key.lower() for key in login.keys()]:
        print("Usuario duplicado, intente nuevamente.")
        user = input("Ingrese Usuario: ")
    return user

def validarUserPass(user: str, pswd: str):
    if user in login and login[user] == pswd:
        print("Inicio de Sesion Exitoso.")
    else:
        print("Usuario o contraseña incorrectos.")

def menu():
    print("\n\nMenu")
    print("1) Registrar Usuario")
    print("2) Listar Usuarios Existentes")
    print("3) Iniciar Sesion")
    print("4) Salir\n")

while True:
    menu()
    try:
        opc = int(input("Eligir Opcion: "))
    except ValueError:
        print("Opción no válida. Ingrese un número válido.")
        continue

    if opc == 1:
        print("\n\n Creacion de Usuario")
        usuario = input("Ingrese Usuario: ")
        usuario = validarLog(usuario)
        clave = input("Ingrese Contraseña: ")
        registrarLog(usuario, clave)

    elif opc == 2:
        print("\nUsuarios Registrados")
        mostrarLog()

    elif opc == 3:
        usuario = input("Ingrese Usuario: ")
        clave = input("Ingrese Contraseña: ")
        validarUserPass(usuario, clave)

    elif opc == 4:
        print("Saliste del programa.")
        break

    else:
        print("Opcion no Valida")