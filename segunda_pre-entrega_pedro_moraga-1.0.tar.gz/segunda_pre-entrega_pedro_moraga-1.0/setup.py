from setuptools import setup

setup(
    name = 'segunda_pre-entrega_pedro_moraga',
    version = '1.0',
    description = 'Segunda pre-entrega del curso de coder python',
    author = 'Pedro Moraga',
    author_email = 'pmoraga2604@icloud.com',
    packages = ['entrega_1','entrega_2']
)